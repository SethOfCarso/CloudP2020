from PIL import Image
import io
import boto3
import sys
import os
from botocore.exceptions import ClientError

from botocore.exceptions import ClientError

s3 = boto3.client('s3')

down1 = s3.get_object( Bucket='bucketpractica2v1', Key = os.environ['image'])
streamBody = down1['Body']
imagen = Image.open(streamBody)
cover = imagen.resize((300,300))
filename = 'resized'+os.environ['image']
format = os.environ['format']

imgByteArr = io.BytesIO()
cover.save(imgByteArr, format=format)
imgByteArr = imgByteArr.getvalue()


def upload_file(file_name, bucket, object_name=None):
    response = s3.put_object(Body=file_name, Bucket=bucket, Key=object_name)
    return True


upload_file(imgByteArr, 'bucketpractica2v1', filename)
