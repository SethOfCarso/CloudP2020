from PIL import Image
from resizeimage import resizeimage
import sys
import boto3

s3 = boto3.client('s3')

BUCKET_NAME = sys.argv[1]
ORIGINAL_IMAGE = sys.argv[2]
RESIZED_IMAGE = sys.argv[3]

s3_object = s3.get_object(Bucket=BUCKET_NAME, Key=ORIGINAL_IMAGE)
with Image.open(s3_object['Body']) as image:
    cover = resizeimage.resize_cover(image, [150,150])
    cover.save(RESIZED_IMAGE, image.format)
    with open(RESIZED_IMAGE, 'r+b') as f:
        s3.upload_fileobj(f, BUCKET_NAME, RESIZED_IMAGE, {'ContentType':s3_object['ContentType']})
