import json
import boto3

client = boto3.client('ecs')

def lambda_handler(event, context):
    records = event['Records']
    key = records[0]['s3']['object']['key']
    r_key = "R" + key

    response = client.run_task(
        cluster='P2-Cluster',
        count=1,
        networkConfiguration={
            'awsvpcConfiguration': {
                'subnets': [
                    'subnet-0f6a03c175d398157',
                ],
                'assignPublicIp': 'ENABLED'
            }
        },
        overrides={
            'containerOverrides': [
                {
                    'name':'ImageResizeContainer',
                    'command': [
                        '/app/resize.sh',
                        'p2-images',
                        key,
                        r_key,
                    ],
                },
            ]
        },
        taskDefinition='imageResizeTaskDefinition'
    )

    print(response)