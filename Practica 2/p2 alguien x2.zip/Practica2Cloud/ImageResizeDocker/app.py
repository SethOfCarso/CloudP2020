from resizeimage import resizeimage
import sys
from PIL import Image
import boto3
import botocore

myBucket = 'practica2intentofinal'
folder = 'insetarImagen/{}'.format(sys.argv[2])
file = sys.argv[2]
credentials = boto3.resource('s3',aws_access_key_id='AKIAQMOSLL6R4NI22UI6',aws_secret_access_key='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')
def resize ():
    try:
        credentials.Bucket(myBucket).download_file(folder, file)
        with open(file, 'r+b') as f:
            print(f)
            with Image.open(f) as originalImage:
                print(originalImage)
                resizeImage = resizeimage.resize_cover(originalImage, [150, 150])
                resultadoImagen = 'imagenSalida_{}'.format(file)
                resizeImage.save(resultadoImagen, originalImage.format)
                print(resultadoImagen)
        credentials.meta.client.upload_file(resultadoImagen, 'practica2intentofinal', 'imagenSalida/{}'.format(file))
        print('done')
    except :
        print('error')

if __name__ = "__main__":
    resize()