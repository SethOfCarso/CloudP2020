#!/bin/bash
python app.py $1 $2

