import boto3

def lambda_handler(event, context):
    file = event.get('Records')[0].get('s3').get('object').get('key')
    salida = file[3:]
    print(salida)
    client = boto3.client('ecs')
    response = client.run_task(cluster='clusterFinal',launchType='FARGATE',taskDefinition='tareaFinal2',count=1,
        networkConfiguration={
            'awsvpcConfiguration': {
                'subnets': [
                    'subnet-3a679265',
                    'subnet-27e60e41',
                    'subnet-1441b635',
                    'subnet-d12f979c'
                ],
                'securityGroups': [
                    'sg-02fa5f562dca9374a'
                ],
                'assignPublicIp':'ENABLED'
            }
        },
        overrides={
            'containerOverrides': [
                {
                    'name': 'containerFinal2',
                    'command': [
                        '/bin/bash', './resize.sh', file, salida
                    ]
                }
            ]
        }
    )
    return str(response)
