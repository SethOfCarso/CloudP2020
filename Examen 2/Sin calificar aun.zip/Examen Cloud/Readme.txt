Secciones que funcionan
    ✔El programa monta VPC y se delimita el CidrBlock que vamos a utilizar (192.168.0.0/16)
    ✔Tiene una subnet para poder tener una CidrBlock mas pequeña que utilizaremos (192.168.100.0/24)
    ✔Tiene una tabla de ruteo, que contiene una ruta.
    ✔Tiene un InternetGateway para poder salir a internet.
    ✔Tiene un security group donde acepto todos los puertos del 0 al 65000 por problemas de comunicacion entre ellos.
    ✔Tiene un ROL que para las arnsPolicis.
    ✔Tiene su perfil de instancias para poder conectarse con la Imagen.
    ✔Tiene un volumen.
    ❌Tiene un taskDefinition donde correo la imagen para la isntancia que NO FUNCIONA ya que al parecer termina el servicio de docker en vez de estar corriendo todo el tiempo.
    ✔Tiene un Cluster para poder lo de Cluster
    ✔Tiene un servicio de Task para el mismo cluster yq eu pueda manejar los task del mismo cluster.
    ❌Mostrar IP y Ping

Descripcion de como trabaja el código

Primero se corren las lo que son las dependencias iniciales que es InternetGateway para poder salir a internet, se crean los roles
iniciales para la creacion, que tienen accesos totales de EC2, accesos totales de ECS y para poder enlazar el container, despues
Se crea el cluster 1, se crea el volumen para tener un espacio de 8, se crea la VPC con un CIDRBLOCK mencionado anteriormente,
Se crean los perfiles de instancia para poder iniciar la Instancia (Que aun no se inicia), se crean las dependencias de la instancia
que son el subnet, la tabla de ruteo, el security group y la conexión entre el security group y la tabla de ruteo, tuve problemas con el
security group que no sabia por que no corria correctamente y al parecer en fue por no tener habiltiado algunos puertos, asi que decidi
abrir todos los puertos. Ya al terminar de iniciar todas las dependencias se inicia la Instancia:
La instancia en un inicio por no querer montar el volumen se tuvo que configurar manualmente a traves de comandos ejecutados en bash,
Se puso la llave para poder entrar y generar pruebas pero es inecesario para la practica, se creo en "us-east-1a", con una instancia micro
y el ami ami-0aee8ced190c05726 que pudiera tener ECS ya para poder trabajar sino daba errores.
Ya que se termina de crear la instancia, se generan los task definition que al parecer un helloworld de docker de google no funcionaba 
Ya que lo eliminaron, asi que al estar probando pro 3 diferentes no funciono y por el tiempo mejor lo deje.
Al final se crea el manejador de servicios par apdoer realizar el taskDef y que este corriendo docker para ello.
La salida si la tiene marcada pero como no corre la instancia de docker, esta nunca llega a ejecutarse, pero si se encuentran.