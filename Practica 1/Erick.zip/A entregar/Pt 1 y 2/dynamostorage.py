import boto3
import json

from botocore.exceptions import ClientError
import config as config


class dynamostorage():

    #dynamodb = boto3.resource('dynamodb', region_name='us-east-1', endpoint_url="http://localhost:8000")
    #dynamodb = boto3.resource('dynamodb')
    #image_table = dynamodb.Table('images_table')
    #labels_table = dynamodb.Table('images_table')

    def __init__(self, tableName="KeyValue", sortKey=False):
        super().__init__()
        dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        #dynamodb = boto3.resource('dynamodb')
        self._table = dynamodb.Table(tableName)



    def put(self, key, value):
        cont = 0
       # image_table = self.dynamodb.Table('images_table')
        response = self._table.put_item(
            Item={
                'keyword' :key,
                'value' : value,
                'inx' : cont
            }
        )

        print(json.dumps(response))
        return print("PutItem succeeded:")

    def putSort(self, key, sort, value):
        response = self._table.put_item(
            Item={
                'keyword': key,
                'value': value,
                'inx': sort
            }
        )

        print(json.dumps(response))
        return print("PutItem succeeded:")

    def get(self, key):
        try:
            response = self._table.get_item(
                Key={
                    'keyword': key
                }
            )
        except ClientError as e:
            print(e.response['Error']['Message'])
        else:
            print(response)
            item = response['Item']
            print("GetItem succeeded:")
            print(json.dumps(item))

    def close(self):
        return print("Cerrar")

