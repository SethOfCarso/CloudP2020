class config():

    def __init__(self):
        region = "us-east-1"

    def getRegion(self):
        region = "us-east-1"
        return region