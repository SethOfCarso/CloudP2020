

class tiple():
#Tener control
# contiene (A) sujeto, (C) predicado y  (B lo que los une) objeto par

    def __init__(self, objeto):
        super().__init__()
        self.words = [3]
        self.words[0] = objeto[0];
        self.words[1] = objeto[1];
        self.words[2] = objeto[2];

    def getValue(self, valor):
        if valor >= 0 & valor < 3:
            return self.words[valor]
        else:
            print("Error en la lectura")


'''
    def __init__(self, sujeto, predicado , objeto):
        super().__init__()
        self.words = []
        self.words[0] = sujeto;
        self.words[1] = predicado;
        self.words[2] = objeto;
'''
