import keyvalue.sqlitekeyvalue as KeyValue
import keyvalue.parsetriples as ParseTriple
import keyvalue.stemmer as Stemmer
import dynamostorage as dynamodb
#Globals

filter = "A"


# Make connections to KeyValue
#kv_labels = KeyValue.SqliteKeyValue("sqlite_labels.db","labels", sortKey=True)
#kv_images = KeyValue.SqliteKeyValue("sqlite_images.db","images")

dy_labels = dynamodb.dynamostorage("labels_table")
dy_images = dynamodb.dynamostorage("images_table")

# Process Logic.
labelDataset = ParseTriple.ParseTriples('./labels_en.ttl')
imageDataset = ParseTriple.ParseTriples('./images.ttl')
'''
print("Images")
print(imageDataset.getNextImages())

print("Labels")
print(labelDataset.getNext())

print(kv_images.get("http://wikidata.dbpedia.org/resource/Q18"))
'''

'''
for i in range (1):
    label = labelDataset.getNext()
    stemmer = Stemmer.stem(label[2])
    for x in stemmer.split(' '):
        print("category: " + label[0] + " =========== label:" + x)
        kv_labels.putSort(x, i, label[0])
'''

'''
Para sql local
print("image")
while 1:
    line = imageDataset.getNextImages()
    if not line:
        break
    if (line[1] == "http://xmlns.com/foaf/0.1/depiction"):
        #print("category: " + line[0] + " ======= imgPath: " + line[2])
        kv_images.put(line[0],line[2])
kv_images.close()
'''


#Para  dynamo
print("image")
#while 1:
for x in range(500):
    line = imageDataset.getNextImages()
    print(line)
    if not line:
        break
    if (line[1] == "http://xmlns.com/foaf/0.1/depiction"):
        print("category: " + line[0] + " ======= imgPath: " + line[2])
        dy_images.put(line[0],line[2])
dy_images.close()


'''
#local
print("label")
cont = 0
while 1:

    line = labelDataset.getNext()
    #print(line[0])
    #print(kv_images.get(line[0]))
    if not line:
        break
    if (line[1] == "http://www.w3.org/2000/01/rdf-schema#label") and kv_images.get(line[0]):
        #print("category: " + line[0] + " ======= label: " + line[2])
        keys = line[2].split()
        for x in keys:
            cont = cont + 1

            print("X es " + x + " Stemmer es " + Stemmer.stem(x))
            kv_labels.putSort(Stemmer.stem(x) , cont,line[0])
'''

#Para dynamo
print("label")
cont = 0
for x in range(500):
    line = labelDataset.getNext()
    if not line:
        break
    #print(line)
    #print(dy_images.get(line[0]))
    #if (line[1] == "http://www.w3.org/2000/01/rdf-schema#label") and dy_images.get(line[0]):
    if (line[1] == "http://www.w3.org/2000/01/rdf-schema#label") :
        #print("category: " + line[0] + " ======= label: " + line[2])
        keys = line[2].split()
        conta12 = "0"
        for x in keys:
            #conta12 = conta12 + 1
            print("X es " + x + " Stemmer es " + Stemmer.stem(x))
            print("cont es " , conta12)
            print(" line es: " , line[0])
            dy_labels.putSort(Stemmer.stem(x) , conta12 , line[0])
dy_labels.close()


# Close KeyValues Storages
#kv_labels.close()
#kv_images.close()






