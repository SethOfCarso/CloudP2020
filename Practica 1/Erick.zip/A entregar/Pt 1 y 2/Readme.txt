El codigo se divide en pocos pasos principales:

En Python:
Primero en loadImages.py
1.- Se hizo como se pidio a travez del uso de sqlitekeyvalue.py se hizo los metodos de get, put para poder meterlos
en una base de datos local.
2.- AL momento de completarlo se paso a queryImages.py
3.- En este se hizo un lector de palabras desde terminal.
4.- Al momento de completar el anterior y funcionara todo correctamente (que pudiera leer desde los archivos con
formato .db) se paso a crear el archivo sqlitekeyvalue pero para poder utilizar Dynamo.
5.-Se pusieron los metodos basicos constructor, get, put , putSort y close. para poder reutilizar el codigo de
loadimages.
6.- Se instancio el archivo de dynamostorage para poder hacer put de lo que pusimos anteriormente en la BD para ponerlo
en dynamo.
7.-Se checa que se hizo el put correcto en dynamo.
8.-Al estar todo correcto se procede a hacer la parte de node.
9.-Se modifica el archivo de config.json para poner de aceurdo a la misma region que tenemos.
10.-Se modifica app.js junto con keyvaluestore para poder tener acceso a dynamo a través de search.
11.- Se prueba que funcione con dynamo y al final se hace EC2
12.- Se crea una instancia de EC2
13.- Se le da permisos para podeer acceder a Dynamo.
14.- Al momento de arrancar se instala node y git para poder descargar desde la nube nuestro repo.
15.- Se corre con npm start y se tiene que acceder a la url publica + el puerto.